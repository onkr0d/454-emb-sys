#ifndef _CRC_16_H
#define _CRC_16_H
#include "types.h"

uint16_t crc_update(uint16_t crc, uint8_t data);

#endif 
